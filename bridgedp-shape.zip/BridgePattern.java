/** Client */
public class BridgePattern {
    public static void main(String[] args) {
        Shape[] shapes = new Shape[3];

        // CircleShapes with different Drawing APIs
        shapes[0] = new CircleShape(1, 2, 3, new DrawingAPI1());
        shapes[1] = new CircleShape(5, 7, 11, new DrawingAPI2());

        // New RectangleShape with DrawingAPI3
        shapes[2] = new RectangleShape(10, 15, 8, 6, new DrawingAPI3());

        for (Shape shape : shapes) {
            shape.resizeByPercentage(1.5);
            shape.draw();
        }
    }
}
