/** "ConcreteImplementor" 3 */
class DrawingAPI3 implements DrawingAPI {
    public void drawCircle(double x, double y, double radius) {
        System.out.printf("API3.circle at %f:%f radius %f\n", x, y, radius);
    }

    public void drawRectangle(double x, double y, double width, double height) {
        System.out.printf("API3.rectangle at %f:%f width %f height %f\n", x, y, width, height);
    }
}
