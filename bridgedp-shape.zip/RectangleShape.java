/** "Refined Abstraction" for Rectangle */
class RectangleShape implements Shape {
    private double x, y, width, height;
    private DrawingAPI drawingAPI;

    public RectangleShape(double x, double y, double width, double height, DrawingAPI drawingAPI) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.drawingAPI = drawingAPI;
    }

    // Low-level implementation
    public void draw() {
        drawingAPI.drawRectangle(x, y, width, height);
    }

    // High-level abstraction
    public void resizeByPercentage(double pct) {
        width *= pct;
        height *= pct;
    }
}
