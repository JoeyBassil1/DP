/** ConcreteImplementor 1 */
class DrawingAPI1 implements DrawingAPI {
    public void drawCircle(double x, double y, double radius) {
        System.out.printf("API1.circle at %f:%f radius %f\n", x, y, radius);
    }

    public void drawRectangle(double x, double y, double width, double height) {
        // Not implemented for this API
        System.out.println("API1 does not support rectangles.");
    }
}
