public class StarbucksCoffee {
    public static void main(String[] args) {
        // Simple Espresso with no add-ons
        Beverage beverage = new Espresso();
        System.out.println(beverage.getDescription() + " $" + beverage.cost());

        // DarkRoast with double Mocha and Whip
        Beverage beverage2 = new DarkRoast();
        beverage2 = new Mocha(beverage2);
        beverage2 = new Mocha(beverage2);
        beverage2 = new Whip(beverage2);
        System.out.println(beverage2.getDescription() + " $" + beverage2.cost());

        // HouseBlend with Mocha, and Whip
        Beverage beverage3 = new HouseBlend();
        beverage3 = new Mocha(beverage3);
        beverage3 = new Whip(beverage3);
        System.out.println(beverage3.getDescription() + " $" + beverage3.cost());

        // New Beverage: Latte with Caramel and Mocha
        Beverage beverage4 = new Latte();
        beverage4 = new Caramel(beverage4);
        beverage4 = new Mocha(beverage4);
        System.out.println(beverage4.getDescription() + " $" + beverage4.cost());
    }
}
